#if !defined(_HEADER_H)
#define _HEADER_H

// #include "IF.h"
// #include "While.h"
#include "Stmts.h"
#include "Decls.h"
#include "Lexical.h" 

#endif // _HEADER_H
